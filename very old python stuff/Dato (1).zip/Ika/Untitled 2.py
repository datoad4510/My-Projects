# Stopwatch
#
# A simple stopwatch that demonstrates the scene module's text
# drawing capabilities.

from scene import *
from time import time
from math import modf
from itertools import chain
import string

class Stopwatch (Scene):
	def setup(self):
		self.start_time = 0.0
		self.stop_time = 0.0
		self.running = False
		#Render all the digits as individual images:
		self.numbers = {}
		font_size = 150 if self.size.w > 700 else 60
		for s in chain(string.digits, [':', '.']):
			#render_text returns a tuple of
			#an image name and its size.
			self.numbers[s] = render_text(s, 'Helvetica-Bold', font_size)
	
	def should_rotate(self, orientation):
		return True
	
	def draw(self):
		background(0, 0, 0)
		#Format the elapsed time (dt):
		dt = 0.0
		if self.running:
			dt = time() - self.start_time
		else:
			dt = self.stop_time - self.start_time
		minutes = dt / 60
		seconds = dt % 60
		centiseconds = modf(dt)[0] * 100
		s = '%02d:%02d.%02d' % (minutes, seconds, centiseconds)
		#Determine overall size for centering:
		w, h = 0.0, self.numbers['0'][1].h
		for c in s:
			size = self.numbers[c][1]
			w += size.w
		#Draw the digits:
		x = int(self.size.w * 0.5 - w * 0.5)
		y = int(self.size.h * 0.5 - h * 0.5)
		for c in s:
			img, size = self.numbers[c]
			image(img, x, y, size.w, size.h)
			x += size.w
	
	def touch_began(self, touch):
		if not self.running:
			if self.start_time > 0:
				#Reset:
				self.start_time = 0.0
				self.stop_time = 0.0
			else:
				#Start:
				self.start_time = time()
				self.running = True
		else:
			#Stop:
			self.stop_time = time()
			self.running = False

run(Stopwatch())

# Piano
# 
# A simple multi-touch piano.

from scene import *
import sound
from itertools import chain

class Key (object):
	def __init__(self, frame):
		self.frame = frame
		self.name = None
		self.touch = None
		self.color = Color(1, 1, 1)
		self.highlight_color = Color(0.9, 0.9, 0.9)
		
	def hit_test(self, touch):
		return touch.location in self.frame

class Piano (Scene):
	def setup(self):
		self.white_keys = []
		self.black_keys = []
		white_key_names = ['Piano_C3', 'Piano_D3', 'Piano_E3',
		                   'Piano_F3', 'Piano_G3', 'Piano_A3', 
		                   'Piano_B3', 'Piano_C4']
		black_key_names = ['Piano_C3#', 'Piano_D3#', 'Piano_F3#', 
		                   'Piano_G3#', 'Piano_A3#']
		for key_name in chain(white_key_names, black_key_names):
			sound.load_effect(key_name)
		white_positions = range(8)
		black_positions = [0.5, 1.5, 3.5, 4.5, 5.5]
		key_w = self.size.w
		key_h = self.size.h / 8
		for i in range(len(white_key_names)):
			pos = white_positions[i]
			key = Key(Rect(0, pos * key_h, key_w, key_h))
			key.name = white_key_names[i]
			self.white_keys.append(key)
		for i in range(len(black_key_names)):
			pos = black_positions[i]
			key = Key(Rect(0, pos * key_h + 10, key_w * 0.6, key_h - 20))
			key.name = black_key_names[i]
			key.color = Color(0, 0, 0)
			key.highlight_color = Color(0.2, 0.2, 0.2)
			self.black_keys.append(key)
		
	def draw(self):
		stroke_weight(1)
		stroke(0.5, 0.5, 0.5)
		for key in chain(self.white_keys, self.black_keys):
			if key.touch is not None:
				fill(*key.highlight_color.as_tuple())
			else:
				fill(*key.color.as_tuple())
			rect(*key.frame.as_tuple())
	
	def touch_began(self, touch):
		for key in chain(self.black_keys, self.white_keys):
			if key.hit_test(touch):
				key.touch = touch
				sound.play_effect(key.name)
				return
	
	def touch_moved(self, touch):
		hit_key = None
		for key in chain(self.black_keys, self.white_keys):
			hit = key.hit_test(touch)
			if hit and hit_key is None:
				hit_key = key
				if key.touch is None:
					key.touch = touch
					sound.play_effect(key.name)
			if key.touch == touch and key is not hit_key:
				key.touch = None
				
	def touch_ended(self, touch):
		for key in chain(self.black_keys, self.white_keys):
			if key.touch == touch:
				key.touch = None

run(Piano(), PORTRAIT)

