def touch_began(self, touch):
		play_effect('Click_1')
		for tile in self.grid:
			if tile is not None: tile.selected = False
		for tile in self.grid:
			if tile is None: continue
			if tile.hit_test(touch):
				self.select_from(tile, set())
				break
				
# Clock
#
# An analog clock that demonstrates drawing basic
# shapes with the scene module.

from scene import *
from time import localtime

ipad = False #will be set in the setup method

#Our Clock class inherits from Scene, so that its draw method
#is automatically called 60 times per second when we run it.
class Clock (Scene):
	def setup(self):
		global ipad
		ipad = self.size.w > 700
	
	def should_rotate(self, orientation):
		return True
	
	def draw(self):
		background(0, 0.2, 0.3)
		t = localtime()
		minute = t.tm_min
		second = t.tm_sec
		hour = t.tm_hour % 12
		margin = 25 if ipad else 5
		r = (min(self.size.w, self.size.h) / 2) - margin * 2
		center = Point(self.size.w/2, self.size.h/2)
		#Draw the clock face:
		fill(0.8, 0.8, 0.8)
		stroke(0.5, 0.5, 0.5)
		line_w = 10 if ipad else 5
		stroke_weight(line_w)
		ellipse(center.x - r, center.y - r, r*2, r*2)
		#Draw 12 markers for the hours:
		push_matrix()
		fill(0.5, 0.5, 0.5)
		no_stroke()
		translate(center.x, center.y)
		digit_w = 20 if ipad else 10
		digit_h = 40 if ipad else 20
		for i in xrange(12):
			rotate(30)
			rect(-digit_w/2, r-digit_h, digit_w, digit_h)
		pop_matrix()
		#Draw the minute hand:
		push_matrix()
		translate(center.x, center.y)
		rotate((-360 / 60) * minute + (-360/60) * (second/60.))
		fill(0, 0, 0)
		m_height = r - (60 if ipad else 30)
		m_width = 20 if ipad else 10
		rect(-m_width/2, -m_width/2, m_width, m_height)
		pop_matrix()
		#Draw the hour hand:
		push_matrix()
		translate(center.x, center.y)
		rotate((-360 / 12) * hour + (-360/12.) * (minute/60.))
		fill(0, 0, 0)
		h_width = 20 if ipad else 10
		h_height = r - (120 if ipad else 60)
		rect(-h_width/2, -h_width/2, h_width, h_height)
		pop_matrix()
		#Draw the second hand:
		push_matrix()
		translate(center.x, center.y)
		rotate((-360 / 60) * second)
		fill(1, 0, 0)
		s_width = 10 if ipad else 6
		s_height = r - (60 if ipad else 20)
		rect(-s_width/2, -s_width/2, s_width, s_height)
		pop_matrix()
		fill(0, 0, 0)
		#Draw the small circle in the middle:
		r = 20 if ipad else 10
		ellipse(center.x - r, center.y - r, r*2, r*2)

#Run the scene that we just defined:
run(Clock())

# Stopwatch
#
# A simple stopwatch that demonstrates the scene module's text
# drawing capabilities.

from scene import *
from time import time
from math import modf
from itertools import chain
import string

class Stopwatch (Scene):
	def setup(self):
		self.start_time = 0.0
		self.stop_time = 0.0
		self.running = False
		#Render all the digits as individual images:
		self.numbers = {}
		font_size = 150 if self.size.w > 700 else 60
		for s in chain(string.digits, [':', '.']):
			#render_text returns a tuple of
			#an image name and its size.
			self.numbers[s] = render_text(s, 'Helvetica-Bold', font_size)
	
	def should_rotate(self, orientation):
		return True
	
	def draw(self):
		background(0, 0, 0)
		#Format the elapsed time (dt):
		dt = 0.0
		if self.running:
			dt = time() - self.start_time
		else:
			dt = self.stop_time - self.start_time
		minutes = dt / 60
		seconds = dt % 60
		centiseconds = modf(dt)[0] * 100
		s = '%02d:%02d.%02d' % (minutes, seconds, centiseconds)
		#Determine overall size for centering:
		w, h = 0.0, self.numbers['0'][1].h
		for c in s:
			size = self.numbers[c][1]
			w += size.w
		#Draw the digits:
		x = int(self.size.w * 0.5 - w * 0.5)
		y = int(self.size.h * 0.5 - h * 0.5)
		for c in s:
			img, size = self.numbers[c]
			image(img, x, y, size.w, size.h)
			x += size.w
	
	def touch_began(self, touch):
		if not self.running:
			if self.start_time > 0:
				#Reset:
				self.start_time = 0.0
				self.stop_time = 0.0
			else:
				#Start:
				self.start_time = time()
				self.running = True
		else:
			#Stop:
			self.stop_time = time()
			self.running = False

run(Stopwatch())

def again():

	answer = raw_input("Again?(y/n) ")
	if answer == 'y':
		calculator()
	elif answer == 'n':
		pass
	else:
		print 'Invalid Input'
		again()

def add():
	a = 0
	num = int(raw_input('How many numbers?'))
	for i in range(num):
		x = float(raw_input('Number: '))
		a = a + x
	print  a
	again()

def substract():
	a = float(raw_input('First number: '))
	b = float(raw_input('Second number: '))
	print  a - b
	again()

def multiply():
	a = 1
	num = int(raw_input('How many numbers?'))
	for i in range(num):
		x = float(raw_input('Number: '))
		a = a*x
	print  a
	again()

def divide():
	a = float(raw_input('First number: '))
	b = float(raw_input('Second number: '))
	print a/b
	again()

def root():
	a = float(raw_input('Number: '))
	b = float(raw_input('Root: '))
	print a**(1/b)
	again()

def power():
	ans = raw_input('Is the number whole?(y/n) ')
	if ans == 'y':
		a = int(raw_input('Number: '))
		b = int(raw_input('Power: '))
		print  a**b
	elif ans == 'n':
		a = float(raw_input('Number: '))
		b = int(raw_input('Power: '))
		print  a**b
	else:
		print 'Invalid Input'
		power()
	again()

def factorial():
	factorial = 1
	a = int(raw_input('Number '))
	for i in range(1,a+1):
		factorial = factorial*i
	print str(factorial)
	again()

def  arythmetycmedium():
	a = float(0)
	b = int(raw_input('How many numbers? '))
	for i in range(b):
		x = float(raw_input('Number: '))
		a = a + x
	print float(a/b)
	again()

def geometrycmedium():
	a = float(1)
	b = float(raw_input('How many numbers? '))
	for i in range(int(b)):
		x = float(raw_input('Number: '))
		a = a*x
	print a**(1/b)
	again()

def harmonicmedium():
	a = float(0)
	b = int(raw_input('How many numbers? '))
	for i in range(b):
		x = float(raw_input('Number: '))
		a = a + (1/x)
	print (1/a)*b
	again()
	

def calculator():
	print '1. Addition'
	print '2. Substraction'
	print '3. Multiplication'
	print '4. Division'
	print '5. Root'
	print '6. Power'
	print '7. Factorial'
	print '8. Arythmetic Medium'
	print '9. Geometric Medium'
	print '10. Harmonic Medium'
	action = raw_input("Choose an action: ")
	if action == '1':
		add()
	elif action == '2':
		substract()
	elif action ==  '3':
		multiply()
	elif action == '4':
		divide()
	elif action == '5':
		root()
	elif action ==  '6':
		power()
	elif action == '7':
		factorial()
	elif action == '8':
		arythmetycmedium()
	elif action == '9':
		geometrycmedium()
	elif action == '10':
		harmonicmedium()
	else:
		print 'Invalid Input'
		calculator()

def password():
	o = '1234'
	x = raw_input('Please enter the password: ')
	if x == o:
		print 'Welcome!'
		calculator()
	else:
		print('Invalid password. Try again.')
		password()

password()

# Sketch
# A very simple drawing 'app' that demonstrates
# custom views and saving images to the camera roll.

import ui
import photos
import console

# The PathView class is responsible for tracking
# touches and drawing the current stroke.
# It is used by SketchView.

class PathView (ui.View):
	def __init__(self, frame):
		self.frame = frame
		self.flex = 'WH'
		self.path = None
		self.action = None
	
	def touch_began(self, touch):
		x, y = touch.location
		self.path = ui.Path()
		self.path.line_width = 8.0
		self.path.line_join_style = ui.LINE_JOIN_ROUND
		self.path.line_cap_style = ui.LINE_CAP_ROUND
		self.path.move_to(x, y)
	
	def touch_moved(self, touch):
		x, y = touch.location
		self.path.line_to(x, y)
		self.set_needs_display()
	
	def touch_ended(self, touch):
		# Send the current path to the SketchView:
		if callable(self.action):
			self.action(self)
		# Clear the view (the path has now been rendered
		# into the SketchView's image view):
		self.path = None
		self.set_needs_display()
	
	def draw(self):
		if self.path:
			self.path.stroke()

# The main SketchView contains a PathView for the current
# line and an ImageView for rendering completed strokes.
# It also manages the 'Clear' and 'Save' ButtonItems that
# are shown in the title bar.

class SketchView (ui.View):
	def __init__(self, width=1024, height=1024):
		self.bg_color = 'white'
		iv = ui.ImageView(frame=(0, 0, width, height))
		pv = PathView(frame=self.bounds)
		pv.action = self.path_action
		self.add_subview(iv)
		self.add_subview(pv)
		save_button = ui.ButtonItem()
		save_button.title = 'Save Image'
		save_button.action = self.save_action
		clear_button = ui.ButtonItem()
		clear_button.title = 'Clear'
		clear_button.tint_color = 'red'
		clear_button.action = self.clear_action
		self.right_button_items = [save_button, clear_button]
		self.image_view = iv
	
	def path_action(self, sender):
		path = sender.path
		old_img = self.image_view.image
		width, height = self.image_view.width, self.image_view.height
		with ui.ImageContext(width, height) as ctx:
			if old_img:
				old_img.draw()
			path.stroke()
			self.image_view.image = ctx.get_image()
	
	def clear_action(self, sender):
		self.image_view.image = None
	
	def save_action(self, sender):
		if self.image_view.image:
			# We draw a new image here, so that it has the current
			# orientation (the canvas is quadratic).
			with ui.ImageContext(self.width, self.height) as ctx:
				self.image_view.image.draw()
				img = ctx.get_image()
				photos.save_image(img)
				console.hud_alert('Saved')
		else:
			console.hud_alert('No Image', 'error')
	
# We use a quadratic canvas, so that the same image
# can be used in portrait and landscape orientation.
w, h = ui.get_screen_size()
canvas_size = max(w, h)

sv = SketchView(canvas_size, canvas_size)
sv.name = 'Sketch'
sv.present('fullscreen')

